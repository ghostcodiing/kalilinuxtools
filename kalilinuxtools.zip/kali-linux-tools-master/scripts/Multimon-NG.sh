sudo apt-get -y install multimon-ng
