sudo apt-get -y install sbd
