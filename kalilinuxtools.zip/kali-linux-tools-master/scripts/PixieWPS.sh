sudo apt-get -y install pixiewps
