sudo apt-get -y install snmpcheck
