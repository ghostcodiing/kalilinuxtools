sudo apt-get -y autoremove
