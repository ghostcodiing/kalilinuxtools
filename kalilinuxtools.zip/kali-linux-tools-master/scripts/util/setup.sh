sudo apt-key adv --keyserver pgp.mit.edu --recv-keys ED444FF07D8D0BF6
sudo apt-get -y update && sudo apt-get -y upgrade && sudo apt-get -y update
sudo apt-get -f -y install

