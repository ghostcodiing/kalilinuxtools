sudo apt-get -y install winexe
