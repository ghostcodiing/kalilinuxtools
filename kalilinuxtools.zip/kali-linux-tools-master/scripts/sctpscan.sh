sudo apt-get -y install sctpscan
