sudo apt-get -y install shellnoob
