sudo apt-get -y install arachni
