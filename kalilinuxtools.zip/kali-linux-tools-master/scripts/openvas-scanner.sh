sudo apt-get -y install openvas-scanner
