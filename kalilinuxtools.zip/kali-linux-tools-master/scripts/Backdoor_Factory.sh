sudo apt-get -y install backdoor-factory
