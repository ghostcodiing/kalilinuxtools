sudo apt-get -y install hexorbase
