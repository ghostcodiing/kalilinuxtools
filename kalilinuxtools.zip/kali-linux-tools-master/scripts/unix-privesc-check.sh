sudo apt-get -y install unix-privesc-check
