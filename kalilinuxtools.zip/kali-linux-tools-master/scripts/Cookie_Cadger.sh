sudo apt-get -y install cookie-cadger
