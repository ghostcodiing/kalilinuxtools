sudo apt-get -y install sipp
