sudo apt-get -y install pdfid
