sudo apt-get -y install u3-pwn
