sudo apt-get -y install dumpzilla
