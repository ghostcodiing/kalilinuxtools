sudo apt-get -y install t50
