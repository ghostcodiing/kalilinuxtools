sudo apt-get -y install crackle
