sudo apt-get -y install hexinject
