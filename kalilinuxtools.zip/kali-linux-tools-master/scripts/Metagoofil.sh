sudo apt-get -y install metagoofil
