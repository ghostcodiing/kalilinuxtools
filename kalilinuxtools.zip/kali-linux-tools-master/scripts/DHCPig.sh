sudo apt-get -y install dhcpig
