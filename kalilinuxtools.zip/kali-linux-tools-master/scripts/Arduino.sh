sudo apt-get -y install arduino
