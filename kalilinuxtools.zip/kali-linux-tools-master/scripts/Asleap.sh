sudo apt-get -y install asleap
