sudo apt-get -y install nishang
