sudo apt-get -y install dns2tcp
