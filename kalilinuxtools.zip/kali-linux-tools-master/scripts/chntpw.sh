sudo apt-get -y install chntpw
