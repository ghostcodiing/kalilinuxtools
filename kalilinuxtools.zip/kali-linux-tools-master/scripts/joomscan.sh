sudo apt-get -y install libswitch-perl
sudo apt-get -y install joomscan
