sudo apt-get -y install burpsuite
