sudo apt-get -y install ohrwurm
