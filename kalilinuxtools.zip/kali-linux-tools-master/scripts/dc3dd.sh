sudo apt-get -y install dc3dd
