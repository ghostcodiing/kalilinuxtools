sudo apt-get -y install cewl
