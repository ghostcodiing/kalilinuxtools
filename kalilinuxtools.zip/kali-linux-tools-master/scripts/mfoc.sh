sudo apt-get -y install mfoc
