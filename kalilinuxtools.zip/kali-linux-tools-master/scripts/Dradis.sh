sudo apt-get -y install dradis
