sudo apt-get -y install xplico
