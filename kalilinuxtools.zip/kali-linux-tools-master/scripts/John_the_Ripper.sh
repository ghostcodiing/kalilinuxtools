sudo apt-get -y install john
