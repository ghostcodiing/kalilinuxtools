sudo apt-get -y install cowpatty
