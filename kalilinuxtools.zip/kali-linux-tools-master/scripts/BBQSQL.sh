sudo apt-get -y install bbqsql
