sudo apt-get -y install aircrack-ng
