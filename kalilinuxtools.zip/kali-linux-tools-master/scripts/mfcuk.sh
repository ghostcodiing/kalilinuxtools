sudo apt-get -y install mfcuk
