sudo apt-get -y install cuckoo
