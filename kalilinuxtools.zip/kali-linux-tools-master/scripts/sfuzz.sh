sudo apt-get -y install sfuzz
