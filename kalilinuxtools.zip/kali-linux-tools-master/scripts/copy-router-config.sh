sudo apt-get -y install copy-router-config
