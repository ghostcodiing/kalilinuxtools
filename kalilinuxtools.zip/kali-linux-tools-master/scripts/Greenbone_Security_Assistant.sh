sudo apt-get -y install greenbone-security-assistant
