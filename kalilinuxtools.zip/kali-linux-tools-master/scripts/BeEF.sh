sudo apt-get -y install beef
