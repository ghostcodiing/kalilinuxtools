sudo apt-get -y install iphone-backup-analyzer
