sudo apt-get -y install fimap
