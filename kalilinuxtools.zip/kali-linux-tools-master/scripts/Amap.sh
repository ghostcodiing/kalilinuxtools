sudo apt-get -y install amap
