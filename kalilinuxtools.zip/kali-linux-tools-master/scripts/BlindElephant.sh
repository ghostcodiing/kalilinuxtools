sudo apt-get -y install blindelephant
