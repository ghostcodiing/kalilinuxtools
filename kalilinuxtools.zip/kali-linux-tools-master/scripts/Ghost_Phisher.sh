sudo apt-get -y install ghost-phisher
