sudo apt-get -y install openvas-manager
