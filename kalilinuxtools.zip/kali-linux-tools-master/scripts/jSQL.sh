sudo apt-get -y install jsql
