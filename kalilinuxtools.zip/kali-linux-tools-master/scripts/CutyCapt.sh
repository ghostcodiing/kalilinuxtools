sudo apt-get -y install cutycapt
