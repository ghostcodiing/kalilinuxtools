sudo apt-get -y install doona
