sudo apt-get -y install sqlmap
