sudo apt-get -y install intrace
