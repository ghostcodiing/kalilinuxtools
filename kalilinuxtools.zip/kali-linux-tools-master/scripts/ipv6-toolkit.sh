sudo apt-get -y install ipv6-toolkit
