sudo apt-get -y install hash-identifier
