sudo apt-get -y install masscan
