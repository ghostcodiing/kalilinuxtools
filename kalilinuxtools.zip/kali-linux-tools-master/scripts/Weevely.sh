sudo apt-get -y install weevely
