sudo apt-get -y install dnswalk
