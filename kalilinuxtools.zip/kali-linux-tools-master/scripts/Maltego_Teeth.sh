sudo apt-get -y install maltego-teeth
