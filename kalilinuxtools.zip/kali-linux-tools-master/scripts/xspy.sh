sudo apt-get -y install xspy
