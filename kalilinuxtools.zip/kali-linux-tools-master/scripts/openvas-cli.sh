sudo apt-get -y install openvas-cli
