sudo apt-get -y install cryptcat
