sudo apt-get -y install rainbowcrack
