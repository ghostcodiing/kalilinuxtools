sudo apt-get -y install findmyhash
