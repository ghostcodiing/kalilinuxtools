sudo apt-get -y install apktool
