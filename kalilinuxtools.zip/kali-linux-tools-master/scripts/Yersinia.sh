sudo apt-get -y install yersinia
