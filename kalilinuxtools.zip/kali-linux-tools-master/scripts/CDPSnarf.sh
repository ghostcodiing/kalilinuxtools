sudo apt-get -y install cdpsnarf
