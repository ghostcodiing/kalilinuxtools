sudo apt-get -y install dmitry
