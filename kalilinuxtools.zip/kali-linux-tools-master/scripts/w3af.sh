sudo apt-get -y install w3af
