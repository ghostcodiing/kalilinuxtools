sudo apt-get -y install uniscan
