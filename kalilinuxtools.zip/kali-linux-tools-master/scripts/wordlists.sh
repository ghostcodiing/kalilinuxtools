sudo apt-get -y install wordlists
