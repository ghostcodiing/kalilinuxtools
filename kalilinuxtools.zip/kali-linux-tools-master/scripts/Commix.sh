sudo apt-get -y install commix
