sudo apt-get -y install ddrescue
