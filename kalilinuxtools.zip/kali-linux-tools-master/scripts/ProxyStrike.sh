sudo apt-get -y install proxystrike
