sudo apt-get -y install hamster-sidejack
