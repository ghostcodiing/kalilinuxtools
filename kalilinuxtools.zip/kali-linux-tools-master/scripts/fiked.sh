sudo apt-get -y install fiked
