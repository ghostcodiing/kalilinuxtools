sudo apt-get -y install binwalk
