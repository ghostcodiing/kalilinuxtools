sudo apt-get -y install dnsmap
