sudo apt-get -y install wol-e
