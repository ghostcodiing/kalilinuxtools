sudo apt-get -y install bully
