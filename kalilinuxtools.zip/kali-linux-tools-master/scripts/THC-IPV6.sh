sudo apt-get -y install thc-ipv6
