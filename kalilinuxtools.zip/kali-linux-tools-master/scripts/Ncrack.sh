sudo apt-get -y install ncrack
