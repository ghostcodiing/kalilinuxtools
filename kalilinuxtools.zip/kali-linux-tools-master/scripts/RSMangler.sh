sudo apt-get -y install rsmangler
