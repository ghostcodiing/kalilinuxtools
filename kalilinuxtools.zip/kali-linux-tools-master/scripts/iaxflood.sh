sudo apt-get -y install iaxflood
