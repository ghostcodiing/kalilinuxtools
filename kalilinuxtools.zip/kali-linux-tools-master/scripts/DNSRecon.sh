sudo apt-get -y install dnsrecon
