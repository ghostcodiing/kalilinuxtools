sudo apt-get -y install enumiax
