sudo apt-get -y install crunch
