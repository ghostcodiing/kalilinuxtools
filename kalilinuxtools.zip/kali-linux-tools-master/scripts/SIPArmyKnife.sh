sudo apt-get -y install siparmyknife
