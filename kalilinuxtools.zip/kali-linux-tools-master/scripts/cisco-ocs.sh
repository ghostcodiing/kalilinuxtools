sudo apt-get -y install cisco-ocs
