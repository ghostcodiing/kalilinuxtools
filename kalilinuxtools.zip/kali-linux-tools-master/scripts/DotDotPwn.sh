sudo apt-get -y install dotdotpwn
