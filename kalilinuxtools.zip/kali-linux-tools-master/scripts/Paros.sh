sudo apt-get -y install paros
