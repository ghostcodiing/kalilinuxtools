sudo apt-get -y install oscanner
