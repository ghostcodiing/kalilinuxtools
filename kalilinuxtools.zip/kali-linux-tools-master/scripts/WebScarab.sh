sudo apt-get -y install webscarab
