sudo apt-get -y install wpscan
