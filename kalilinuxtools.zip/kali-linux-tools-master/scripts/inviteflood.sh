sudo apt-get -y install inviteflood
