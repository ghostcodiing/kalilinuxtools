sudo apt-get -y install bluelog
