sudo apt-get -y install mdk3
