sudo apt-get -y install dos2unix
