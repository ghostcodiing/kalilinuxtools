sudo apt-get -y install skipfish
