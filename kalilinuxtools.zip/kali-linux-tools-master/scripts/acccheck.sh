sudo apt-get -y install accheck
