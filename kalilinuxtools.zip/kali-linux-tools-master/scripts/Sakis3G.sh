sudo apt-get -y install sakis3g
