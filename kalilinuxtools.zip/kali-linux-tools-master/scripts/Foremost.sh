sudo apt-get -y install foremost
