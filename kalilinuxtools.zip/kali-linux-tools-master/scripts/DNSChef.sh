sudo apt-get -y install dnschef
