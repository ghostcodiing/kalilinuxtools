sudo apt-get -y install sslyze
