sudo apt-get -y install wifite
