sudo apt-get -y install reaver
