sudo apt-get -y install bluesnarfer
