sudo apt-get -y install magictree
