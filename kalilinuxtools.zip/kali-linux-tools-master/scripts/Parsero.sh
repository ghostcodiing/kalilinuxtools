sudo apt-get -y install parsero
