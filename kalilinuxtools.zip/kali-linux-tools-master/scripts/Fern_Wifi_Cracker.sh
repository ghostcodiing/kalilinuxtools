sudo apt-get -y install fern-wifi-cracker
