sudo apt-get -y install javasnoop
