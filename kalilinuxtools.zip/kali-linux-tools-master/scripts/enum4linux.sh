sudo apt-get -y install enum4linux
