sudo apt-get -y install blueranger
