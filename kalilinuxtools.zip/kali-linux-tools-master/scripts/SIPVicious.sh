sudo apt-get -y install sipvicious
