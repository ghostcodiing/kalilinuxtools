sudo apt-get -y install webshells
