sudo apt-get -y install jboss-autopwn
