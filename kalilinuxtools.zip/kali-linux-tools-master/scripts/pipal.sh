sudo apt-get -y install pipal
