sudo apt-get -y install edb-debugger
