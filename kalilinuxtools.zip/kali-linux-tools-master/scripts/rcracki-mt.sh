sudo apt-get -y install rcracki-mt
