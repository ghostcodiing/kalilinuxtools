sudo apt-get -y install miranda
