sudo apt-get -y install statsprocessor
