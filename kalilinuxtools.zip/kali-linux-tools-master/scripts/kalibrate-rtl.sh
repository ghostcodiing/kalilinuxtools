sudo apt-get -y install kalibrate-rtl
