sudo apt-get -y install truecrack
