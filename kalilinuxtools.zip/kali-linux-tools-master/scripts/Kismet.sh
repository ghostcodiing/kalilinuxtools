sudo apt-get -y install kismet
