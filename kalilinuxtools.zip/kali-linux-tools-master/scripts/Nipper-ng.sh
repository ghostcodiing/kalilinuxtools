sudo apt-get -y install nipper-ng
