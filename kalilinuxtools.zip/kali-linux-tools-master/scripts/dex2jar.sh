sudo apt-get -y install dex2jar
