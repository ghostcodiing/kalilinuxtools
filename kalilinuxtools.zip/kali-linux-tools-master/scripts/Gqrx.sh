sudo apt-get -y install gqrx
