sudo apt-get -y install wfuzz
