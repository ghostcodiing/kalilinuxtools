sudo apt-get -y install rtlsdr-scanner
