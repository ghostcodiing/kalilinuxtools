sudo apt-get -y install keepnote
