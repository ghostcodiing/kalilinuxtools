sudo apt-get -y install lynis
