sudo apt-get -y install cmospwd
