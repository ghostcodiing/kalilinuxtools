sudo apt-get -y install killerbee
