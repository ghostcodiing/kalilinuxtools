sudo apt-get -y install multiforcer
