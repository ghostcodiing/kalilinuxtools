sudo apt-get -y install vega
