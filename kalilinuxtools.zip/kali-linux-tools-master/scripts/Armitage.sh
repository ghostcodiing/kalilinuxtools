sudo apt-get -y install armitage
