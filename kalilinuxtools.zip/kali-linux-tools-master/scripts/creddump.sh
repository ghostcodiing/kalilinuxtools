sudo apt-get -y install creddump
