sudo apt-get -y install dirb
