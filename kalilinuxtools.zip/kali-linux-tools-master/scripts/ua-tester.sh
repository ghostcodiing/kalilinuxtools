sudo apt-get -y install ua-tester
