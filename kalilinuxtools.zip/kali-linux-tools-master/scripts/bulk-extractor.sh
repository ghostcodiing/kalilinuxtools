sudo apt-get -y install bulk-extractor
