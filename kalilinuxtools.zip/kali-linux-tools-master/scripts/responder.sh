sudo apt-get -y install responder
